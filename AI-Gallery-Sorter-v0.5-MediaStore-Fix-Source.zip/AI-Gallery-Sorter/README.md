# AI Gallery Sorter — Android MVP 0.1.0

A privacy-first Android starter app for reference-image visual similarity search. Targeted at Android 11+ (including Samsung Galaxy M35). It scans images exposed by Android MediaStore, computes on-device image embeddings, shows ranked matches, and requests Android's native deletion confirmation only after the user selects items.

## Current MVP behaviour

- Automatic visual similarity from a chosen reference image (not OCR or a guaranteed semantic category classifier).
- Gallery-wide scan of images accessible through Android's photo permission.
- Adjustable cosine-similarity threshold.
- Local inference; no app networking permission is declared.
- Manual selection and Android `MediaStore.createDeleteRequest` confirmation for deletion.

## Important model setup

This project intentionally does not bundle a model binary. In Android Studio, build/install the app, then import a compatible MediaPipe Image Embedder `.tflite` model using the in-app model picker. A model must expose the embedding output expected by MediaPipe Tasks Image Embedder; arbitrary classification `.tflite` files will not work.

Official MediaPipe Image Embedder documentation and Android sample:
- https://ai.google.dev/edge/mediapipe/solutions/vision/image_embedder/android
- https://ai.google.dev/edge/mediapipe/solutions/vision/image_embedder

Use the official model links listed by the documentation. Download/import the model once; after that, scanning/inference works offline. The model itself is stored in app memory for the current run in this MVP; re-import after restarting the app.

## Build

1. Install Android Studio Ladybug or newer, Android SDK 35, and JDK 17.
2. Open this folder (`AI-Gallery-Sorter`) in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install `app/build/outputs/apk/debug/app-debug.apk` on the Galaxy M35.
6. Grant photo access, import a compatible model file, choose a reference image, then scan.

## Limitations of this first cut

- Similarity scores are relative model scores, not calibrated probabilities.
- Visual embedding similarity can miss category matches with very different layouts and can include false positives. Review every result.
- A single reference image is used; there is no multi-example category profile yet.
- The scan is synchronous on a background coroutine and does not yet persist an index or resume interrupted scans.
- Large galleries may take time and consume battery. Run while charging for a first full scan.
- Model compatibility and performance must be validated on the target phone before calling this a production APK.

## Privacy

No INTERNET permission is declared. Images are read through Android's content provider and are not uploaded. Android's system deletion consent UI is used for selected matches. The app does not silently delete files.


## Version 0.2.0

New scan filters:
- Inclusive From and To dates (either may be left unset).
- Device-folder selection; leaving folders unselected scans all indexed image folders.
- Date filtering uses the photo capture date when available and falls back to the MediaStore date-added value.

The app continues to process images locally. Matching images are shown for manual review, and Android confirmation is required before deletion.
