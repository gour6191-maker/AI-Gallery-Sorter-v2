package com.majilab.gallerysorter

import android.content.ContentUris
import android.content.IntentSender
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.content.pm.PackageManager
import android.Manifest
import androidx.core.content.ContextCompat
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Checkbox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedder
import com.google.mediapipe.tasks.vision.imageembedder.ImageEmbedderOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

private data class Match(val uri: Uri, val score: Float, val bitmap: Bitmap)

class MainActivity : ComponentActivity() {
    private var embedder: ImageEmbedder? = null
    private var modelBuffer: ByteBuffer? = null
    private var pendingDelete: List<Uri> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GallerySorterScreen() }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun GallerySorterScreen() {
        var modelReady by remember { mutableStateOf(false) }
        var referenceName by remember { mutableStateOf("No reference image selected") }
        var status by remember { mutableStateOf("Import an image model to begin. Everything runs on this phone.") }
        var busy by remember { mutableStateOf(false) }
        var threshold by remember { mutableFloatStateOf(0.55f) }
        var matches by remember { mutableStateOf<List<Match>>(emptyList()) }
        var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
        var pendingReference by remember { mutableStateOf<Uri?>(null) }
        var startDateMillis by remember { mutableStateOf<Long?>(null) }
        var endDateMillis by remember { mutableStateOf<Long?>(null) }
        var showStartPicker by remember { mutableStateOf(false) }
        var showEndPicker by remember { mutableStateOf(false) }
        var showFolderDialog by remember { mutableStateOf(false) }
        var availableFolders by remember { mutableStateOf<List<String>>(emptyList()) }
        var selectedFolders by remember { mutableStateOf<Set<String>>(emptySet()) }

        val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                busy = true
                status = "Loading model locally…"
                lifecycleScope.launch {
                    try {
                        val bytes = withContext(Dispatchers.IO) {
                            contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                        }
                        val buffer = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
                        buffer.put(bytes); buffer.rewind()
                        withContext(Dispatchers.Default) {
                            val options = ImageEmbedderOptions.builder()
                                .setBaseOptions(BaseOptions.builder().setModelAssetBuffer(buffer).build())
                                .setL2Normalize(true).build()
                            embedder?.close()
                            embedder = ImageEmbedder.createFromOptions(this@MainActivity, options)
                        }
                        modelBuffer = buffer
                        modelReady = true
                        status = "Model ready. Select a reference image to search your gallery."
                    } catch (e: Exception) {
                        status = "Could not load this model: ${e.message ?: "unsupported model file"}"
                    } finally { busy = false }
                }
            }
        }
        val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val ref = pendingReference
            if (granted && ref != null && modelReady) {
                runScan(ref, threshold, startDateMillis, endDateMillis, selectedFolders, { busy = it }, { status = it }, { found -> matches = found; selected = emptySet() })
            } else if (!granted) status = "Allow access to all photos in Android settings to scan the full gallery."
            pendingReference = null
        }
        val referencePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                referenceName = uri.lastPathSegment?.substringAfterLast('/') ?: "Reference image selected"
                if (!modelReady) status = "Now import a compatible MediaPipe Image Embedder .tflite model."
                else {
                    val imagePermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
                    if (ContextCompat.checkSelfPermission(this@MainActivity, imagePermission) == PackageManager.PERMISSION_GRANTED) {
                        runScan(uri, threshold, startDateMillis, endDateMillis, selectedFolders, { busy = it }, { status = it }, { found -> matches = found; selected = emptySet() })
                    } else {
                        pendingReference = uri
                        permissionLauncher.launch(imagePermission)
                    }
                }
            }
        }
        val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                status = "Deletion approved. Android has processed the selected items."
                matches = matches.filterNot { it.uri in pendingDelete }
                selected = emptySet()
            } else status = "Deletion cancelled. Your photos were not intentionally removed by this app."
            pendingDelete = emptyList()
        }

        MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF315EFB))) {
            Surface(Modifier.fillMaxSize(), color = androidx.compose.ui.graphics.Color(0xFFF7F8FC)) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
                    Text("AI Gallery Sorter", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Private, on-device visual category search", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    Spacer(Modifier.height(18.dp))
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("LOCAL AI MODEL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(Modifier.weight(1f))
                                Text(if (modelReady) "READY" else "NOT SET UP", color = if (modelReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("The model file is selected from your device and stays on your device.", fontSize = 13.sp)
                            Button(onClick = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-tflite", "*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("1 · Import image model (.tflite)") }
                            OutlinedButton(onClick = { referencePicker.launch("image/*") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("2 · Choose reference image") }
                            Text(referenceName, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Scan filters", fontWeight = FontWeight.Bold)
                            Text("Limit the scan to a date range and selected device folders. Leave dates empty and folders unselected to scan everything.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { showStartPicker = true }, modifier = Modifier.weight(1f)) {
                                    Text("From: ${startDateMillis?.let { formatDate(it) } ?: "Any date"}", fontSize = 11.sp)
                                }
                                OutlinedButton(onClick = { showEndPicker = true }, modifier = Modifier.weight(1f)) {
                                    Text("To: ${endDateMillis?.let { formatDate(it) } ?: "Any date"}", fontSize = 11.sp)
                                }
                            }
                            OutlinedButton(onClick = {
                                busy = true
                                lifecycleScope.launch {
                                    availableFolders = withContext(Dispatchers.IO) { queryImageFolders() }
                                    busy = false
                                    showFolderDialog = true
                                }
                            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                                Text(if (selectedFolders.isEmpty()) "Choose device folders (All folders)" else "Folders selected: ${selectedFolders.size}")
                            }
                            if (startDateMillis != null || endDateMillis != null || selectedFolders.isNotEmpty()) {
                                TextButton(onClick = { startDateMillis = null; endDateMillis = null; selectedFolders = emptySet() }) { Text("Clear scan filters") }
                            }
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Match sensitivity", fontWeight = FontWeight.SemiBold)
                            Text("${(threshold * 100).toInt()}% similarity threshold", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Slider(value = threshold, onValueChange = { threshold = it }, valueRange = 0.30f..0.90f)
                            Text("Higher = stricter visual matches. Lower = broader category matches.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
                    Text(status, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Matches (${matches.size})", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        TextButton(onClick = { selected = if (selected.size == matches.size) emptySet() else matches.map { it.uri.toString() }.toSet() }, enabled = matches.isNotEmpty()) { Text(if (selected.size == matches.size) "Deselect all" else "Select all") }
                    }
                    if (matches.isEmpty()) {
                        Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) {
                            Text("Your matching images will appear here after a scan.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                    } else {
                        LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxWidth().height(420.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(matches, key = { it.uri.toString() }) { match ->
                                Column(Modifier.clickable {
                                    val key = match.uri.toString(); selected = if (key in selected) selected - key else selected + key
                                }) {
                                    Box {
                                        Image(match.bitmap.asImageBitmap(), null, Modifier.fillMaxWidth().height(116.dp))
                                        if (match.uri.toString() in selected) Text("✓", Modifier.align(Alignment.TopEnd).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp)).padding(5.dp), color = androidx.compose.ui.graphics.Color.White)
                                    }
                                    Text("${(match.score * 100).toInt()}% match", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                    Button(onClick = {
                        val uris = matches.filter { it.uri.toString() in selected }.map { it.uri }
                        if (uris.isNotEmpty()) {
                            try {
                                pendingDelete = uris
                                val request = MediaStore.createDeleteRequest(contentResolver, uris)
                                deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
                            } catch (e: Exception) { status = "Could not start Android deletion approval: ${e.message}" }
                        }
                    }, enabled = selected.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()) { Text("Review & delete ${selected.size} selected") }
                    Text("Deletion always requires Android's confirmation screen. No auto-delete.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
                }
            }
            if (showStartPicker) {
                val pickerState = rememberDatePickerState(initialSelectedDateMillis = startDateMillis ?: System.currentTimeMillis())
                DatePickerDialog(onDismissRequest = { showStartPicker = false }, confirmButton = {
                    TextButton(onClick = { startDateMillis = pickerState.selectedDateMillis; showStartPicker = false }) { Text("Set") }
                }, dismissButton = { TextButton(onClick = { showStartPicker = false }) { Text("Cancel") } }) {
                    DatePicker(state = pickerState)
                }
            }
            if (showEndPicker) {
                val pickerState = rememberDatePickerState(initialSelectedDateMillis = endDateMillis ?: System.currentTimeMillis())
                DatePickerDialog(onDismissRequest = { showEndPicker = false }, confirmButton = {
                    TextButton(onClick = { endDateMillis = pickerState.selectedDateMillis; showEndPicker = false }) { Text("Set") }
                }, dismissButton = { TextButton(onClick = { showEndPicker = false }) { Text("Cancel") } }) {
                    DatePicker(state = pickerState)
                }
            }
            if (showFolderDialog) {
                AlertDialog(onDismissRequest = { showFolderDialog = false },
                    title = { Text("Choose folders") },
                    text = {
                        Column(Modifier.heightIn(max = 420.dp)) {
                            Text("No folders selected means all folders are included.", fontSize = 12.sp)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = selectedFolders.isEmpty(), onCheckedChange = { if (it) selectedFolders = emptySet() })
                                Text("All folders")
                            }
                            availableFolders.forEach { folder ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = folder in selectedFolders, onCheckedChange = { checked ->
                                        selectedFolders = if (checked) selectedFolders + folder else selectedFolders - folder
                                    })
                                    Text(folder, fontSize = 12.sp)
                                }
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { showFolderDialog = false }) { Text("Done") } },
                    dismissButton = { TextButton(onClick = { selectedFolders = emptySet(); showFolderDialog = false }) { Text("All folders") } }
                )
            }
        }
    }

    private fun formatDate(millis: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(millis))

    private fun queryImageFolders(): List<String> {
        val folders = linkedSetOf<String>()
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        contentResolver.query(collection, arrayOf(MediaStore.Images.Media.RELATIVE_PATH), null, null, null)?.use { cursor ->
            val pathCol = cursor.getColumnIndex(MediaStore.Images.Media.RELATIVE_PATH)
            if (pathCol >= 0) while (cursor.moveToNext()) {
                val path = cursor.getString(pathCol)
                if (!path.isNullOrBlank()) folders.add(path.trimEnd('/'))
            }
        }
        return folders.sorted()
    }

    private fun runScan(reference: Uri, threshold: Float, startDateMillis: Long?, endDateMillis: Long?, selectedFolders: Set<String>, setBusy: (Boolean) -> Unit, setStatus: (String) -> Unit, onDone: (List<Match>) -> Unit) {
        val engine = embedder ?: run { setStatus("Import a compatible image model first."); return }
        if (startDateMillis != null && endDateMillis != null && startDateMillis > endDateMillis) {
            setStatus("Start date must be on or before the end date."); return
        }
        setBusy(true); setStatus("Scanning gallery locally…")
        lifecycleScope.launch {
            try {
                val found = withContext(Dispatchers.IO) {
                    val refBitmap = decodeScaled(reference, 480) ?: error("Cannot read reference image")
                    val refVector = engine.embed(BitmapImageBuilder(refBitmap).build()).embeddings().first().floatEmbedding()
                    val results = mutableListOf<Match>()
                    val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                    val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.RELATIVE_PATH)
                    val clauses = mutableListOf<String>()
                    val args = mutableListOf<String>()
                    val startSeconds = startDateMillis?.div(1000L)
                    val endExclusiveSeconds = endDateMillis?.div(1000L)?.plus(86400L)
                    val effectiveDate = "(CASE WHEN ${MediaStore.Images.Media.DATE_TAKEN} > 0 THEN ${MediaStore.Images.Media.DATE_TAKEN}/1000 ELSE ${MediaStore.Images.Media.DATE_ADDED} END)"
                    if (startSeconds != null) { clauses.add("$effectiveDate >= ?"); args.add(startSeconds.toString()) }
                    if (endExclusiveSeconds != null) { clauses.add("$effectiveDate < ?"); args.add(endExclusiveSeconds.toString()) }
                    if (selectedFolders.isNotEmpty()) {
                        clauses.add("${MediaStore.Images.Media.RELATIVE_PATH} IN (${selectedFolders.joinToString(",") { "?" }})")
                        args.addAll(selectedFolders)
                    }
                    val selection = clauses.takeIf { it.isNotEmpty() }?.joinToString(" AND ")
                    contentResolver.query(collection, projection, selection, args.takeIf { it.isNotEmpty() }?.toTypedArray(), "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { cursor ->
                        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                        var checked = 0
                        while (cursor.moveToNext()) {
                            val id = cursor.getLong(idCol)
                            val uri = ContentUris.withAppendedId(collection, id)
                            if (uri == reference) continue
                            try {
                                val scaled = decodeScaled(uri, 320) ?: continue
                                val vector = engine.embed(BitmapImageBuilder(scaled).build()).embeddings().first().floatEmbedding()
                                val score = cosine(refVector, vector)
                                if (score >= threshold) results.add(Match(uri, score, Bitmap.createScaledBitmap(scaled, 180, (180f * scaled.height / scaled.width).toInt().coerceAtLeast(1), true)))
                                scaled.recycle()
                                checked++
                                if (checked % 40 == 0) withContext(Dispatchers.Main) { setStatus("Scanned $checked images · ${results.size} matches") }
                            } catch (_: Exception) { /* Skip unreadable or unsupported media; continue scan. */ }
                        }
                    }
                    results.sortedByDescending { it.score }
                }
                onDone(found); setStatus("Scan complete. ${found.size} possible matches found.")
            } catch (e: Exception) { setStatus("Scan failed: ${e.message ?: "unknown error"}") }
            finally { setBusy(false) }
        }
    }


    private fun decodeScaled(uri: Uri, maxDimension: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxDimension) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.RGB_565 }
        return contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }

    private fun cosine(a: FloatArray, b: FloatArray): Float {
        val n = minOf(a.size, b.size); var dot = 0f; var aa = 0f; var bb = 0f
        for (i in 0 until n) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i] }
        return if (aa == 0f || bb == 0f) 0f else (dot / (sqrt(aa) * sqrt(bb))).coerceIn(-1f, 1f)
    }

    override fun onDestroy() { embedder?.close(); super.onDestroy() }
}
